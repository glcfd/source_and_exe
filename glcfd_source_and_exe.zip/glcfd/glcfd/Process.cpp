#include "Process.h"
#include "shaders.h"

string Process::TTS_FS_FILE = "tts_fs.glsl";

static const GLfloat g_quad_vertex_buffer_data[] = {
	-1.0f, -1.0f, 0.0f,
	1.0f, -1.0f, 0.0f,
	-1.0f,  1.0f, 0.0f,
	-1.0f,  1.0f, 0.0f,
	1.0f, -1.0f, 0.0f,
	1.0f,  1.0f, 0.0f,
};

GLuint Process::getResult()
{
	assert(constructed);
	return renderedtexture;
}


Process::Process() : constructed(false)
{

}


void Process::setType(ResultType rt)
{
	if (rt == FLOAT32C1)
	{
		internalformat = GL_R32F;
		format = GL_R;
		type = GL_FLOAT;
	}
	else if(rt == FLOAT32C2)
	{
		internalformat = GL_RG32F;
		format = GL_RG;
		type = GL_FLOAT;
	}
	else if (rt == FLOAT32C3)
	{
		internalformat = GL_RGB32F;
		format = GL_RGB;
		type = GL_FLOAT;
	}
}

Process::Process(
	string fs_file
	) : constructed(true)
{
	result_type = FLOAT32C3;
	renderToScreen = fs_file == TTS_FS_FILE;

	if (renderToScreen)
	{
		w = g_screen_w;
		h = g_screen_h;
		framebuffer = 0;
		program = LoadShaders("passthrough_vs.glsl", TTS_FS_FILE.c_str());
	}
	else 
	{
		// rtt
		w = g_sim_w;
		h = g_sim_h;
		glGenFramebuffers(1, &framebuffer);

		glBindFramebuffer(GL_FRAMEBUFFER, framebuffer);

		glGenTextures(1, &renderedtexture);

		// all texture functions calls will affect the bound texture
		glBindTexture(GL_TEXTURE_2D, renderedtexture);

		
		setType(result_type);
		// give empty image (the last "0")
		glTexImage2D(GL_TEXTURE_2D, 0, internalformat, g_sim_w, g_sim_h, 0, format, type, 0);

		// Poor filtering. Needed!
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

		// set renderedtexture as color attachment 0
		glFramebufferTexture(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, renderedtexture, 0);

		// set the list of drawbuffers
		GLenum drawbuffers[1] = { GL_COLOR_ATTACHMENT0 };
		glDrawBuffers(1, drawbuffers);

		// Always check that our framebuffer is ok
		if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
			assert(false);

		program = LoadShaders("passthrough_vs.glsl", fs_file.c_str());
		
	}

	

	
	



	glGenVertexArrays(1, &quad_vertexarray);
	glBindVertexArray(quad_vertexarray);

	glGenBuffers(1, &quad_vertexbuffer);
	glBindBuffer(GL_ARRAY_BUFFER, quad_vertexbuffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(g_quad_vertex_buffer_data),
		g_quad_vertex_buffer_data, GL_STATIC_DRAW);





}

void Process::storeTTSInput(GLuint tex)
{
	assert(constructed);
	assert(renderToScreen);
	input_texs.push_back(tex);
	input_uniform_names.push_back("input_texture");
}

void Process::storeInputs(vector<GLuint> texs, vector<string> & uniform_names)
{
	assert(constructed);
	assert(!renderToScreen);
	input_texs = texs;
	input_uniform_names = uniform_names;
	
}

void Process::setInputs()
{
	assert(constructed);

	glUseProgram(program);


	int n = input_texs.size();
	for (int i = 0; i < n; i++)
	{
		auto tex = input_texs[i];
		auto uname = input_uniform_names[i];
		auto u = glGetUniformLocation(program, uname.c_str());


		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, tex);

		
		glUniform1i(u, i);
	}

}

void Process::setInt(int i, string name)
{
	//precondition: use program
	auto u = glGetUniformLocation(program, name.c_str());
	glUseProgram(program);
	glUniform1i(u, i);
}
void Process::setFloat(float f, string name)
{
	//precondition: use program
	
	auto u = glGetUniformLocation(program, name.c_str());
	glUseProgram(program);
	glUniform1f(u, f);
}

GLuint Process::execute(bool clear)
{
	assert(constructed);

	glBindFramebuffer(GL_FRAMEBUFFER, framebuffer);
	glViewport(0, 0, w, h);
	if(clear) glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glUseProgram(program);


	setInputs();

	// 1st attribute buffer : vertices
	glEnableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, quad_vertexbuffer);
	glVertexAttribPointer(
		0,			// attribute 0.
		3,			// size
		GL_FLOAT,	// type
		GL_FALSE,	// normalized
		0,			// stride
		(void*)0	// array buffer offset
	);

	glDrawArrays(GL_TRIANGLES, 0, 6);
	glDisableVertexAttribArray(0);

	return renderedtexture;
}

Process::~Process()
{
}
