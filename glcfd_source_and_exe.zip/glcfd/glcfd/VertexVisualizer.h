#pragma once
#include <vector>
#include <string>
#include <GL/glew.h>

using namespace std;

class VertexVisualizer
{
private:
	bool constructed = false;
	
	int num_verts = 0;

	vector<GLuint> input_texs;
	vector<string> input_uniform_names;

	GLuint vertexarray;
	GLuint vertexbuffer;
	GLuint program;

	void setInputs();

public:

	

	void storeInputs(vector<GLuint> texs, vector<string> & uniform_names);
	void setInt(int i, string name);
	void setFloat(float f, string name);
	void execute();

	VertexVisualizer();
	VertexVisualizer(int num_verts_, string vs_file, string fs_file);

	~VertexVisualizer();
};

