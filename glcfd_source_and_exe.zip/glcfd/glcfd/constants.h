#pragma once

extern int g_sim_w;
extern int g_sim_h;

extern int g_screen_w;
extern int g_screen_h;
extern int g_screen_x;
extern int g_screen_y;
