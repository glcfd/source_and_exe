#include "rtt2.h"
#include "Process.h"
#include <vector>
#include "VertexVisualizer.h"
using namespace std;

static Process checkerboard;
static Process centerdot;
static Process dilate;


static Process velocity_initial;
static Process advection;
static Process diffusiona;
static Process diffusionb;
static Process force;
static Process divergence;
static Process pressurea;
static Process pressureb;
static Process pressure_initial;
static Process gradient_subtraction;
static Process velocity_visualize;

static GLuint f_texture;
static GLfloat f_array[3 * 100 * 100] = {};	// set all to zero


static Process tts;


static Process point_position_initialize;
static Process point_position_integratora;
static Process point_position_integratorb;

static VertexVisualizer vertex_visualizer;


void rtt2_addForce(int i, int j, float vx, float vy)
{
	//glBindTexture(GL_TEXTURE_2D, f_texture);

	auto & f = f_array;



	int idx = i + j * 100;

	f[3 * idx + 0] += vx;
	f[3 * idx + 1] += vy;
	f[3 * idx + 2] = 0;




	//glTexSubImage2D(GL_TEXTURE_2D, 0, i, j, g_sim_w, g_sim_h, GL_RGB, GL_FLOAT, f);
	//glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB32F, g_sim_w, g_sim_h, 0, GL_RGB, GL_FLOAT, f);
}


static void safeInitialize()
{
	static bool initialized = false;
	if (initialized) return;
	initialized = true;

	//checkerboard = Process("checkerboard_fs.glsl");
	//centerdot = Process("centerdot_fs.glsl");
	//dilate = Process("dilate_fs.glsl");


	velocity_initial = Process("velocity_initial_fs.glsl");
	advection = Process("advection_fs.glsl");

	diffusiona = Process("jacobi_fs.glsl");
	diffusionb = Process("jacobi_fs.glsl");

	force = Process("force_fs.glsl");

	divergence = Process("divergence_fs.glsl");

	pressurea = Process("jacobi_fs.glsl");
	pressureb = Process("jacobi_fs.glsl");

	pressure_initial = Process("pressure_initial_fs.glsl");

	gradient_subtraction = Process("gradient_subtraction_fs.glsl");

	velocity_visualize = Process("velocity_visualize_fs.glsl");

	tts = Process(Process::TTS_FS_FILE);

	{
		// force texture
		glGenTextures(1, &f_texture);
		glBindTexture(GL_TEXTURE_2D, f_texture);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB32F, g_sim_w, g_sim_h, 0, GL_RGB, GL_FLOAT, 0);
		// last 0 is empty texture
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

		//GLfloat f[3 * 100 * 100] = {};	// all set to zero
		auto & f = f_array;

		int n = 30;
		int i = 25;
		int j = 25;
		int idx = i + j * 100;

		f[3 * idx + 0] = 0;
		f[3 * idx + 1] = 0;
		f[3 * idx + 2] = 0;



		//glTexSubImage2D(GL_TEXTURE_2D, 0, i, j, g_sim_w, g_sim_h, GL_RGB, GL_FLOAT, f);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB32F, g_sim_w, g_sim_h, 0, GL_RGB, GL_FLOAT, f);
	}

	point_position_initialize = Process("point_position_initialize_fs.glsl");
	point_position_integratora = Process("point_position_integrator_fs.glsl");
	point_position_integratorb = Process("point_position_integrator_fs.glsl");
	vertex_visualizer = VertexVisualizer(
		100 * 100,
		"vertex_visualizer_vs.glsl",
		"vertex_visualizer_fs.glsl");

}

void rtt2()
{
	safeInitialize();

	//auto cbr = checkerboard.execute();
	//auto cdr = centerdot.execute();
	//dilate.storeInputs(
	//	vector<GLuint>{ cdr }, 
	//	vector<string>{ "dot_texture" }
	//);
	//auto dr = dilate.execute();


	
	
	static GLuint velocity_texture;

	static bool velocity_initialized = false;
	if (!velocity_initialized) {
		velocity_initialized = true;
		auto vir = velocity_initial.execute();
		velocity_texture = vir;
	}
	


	glBindTexture(GL_TEXTURE_2D, f_texture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB32F, g_sim_w, g_sim_h, 0, GL_RGB, GL_FLOAT, f_array);

	force.storeInputs(
	{ f_texture,velocity_texture },
		vector<string>{"f_texture", "v_texture"}
	);
	auto fr = force.execute();
	//fill(begin(f_array), end(f_array), 0);	// clear

	// don't clear, but bleed off
	int fsize = sizeof(f_array) / sizeof(*f_array);
	for (int i = 0; i < fsize; i++)
	{
		f_array[i] = f_array[i] * .8;
	}



	advection.storeInputs(
		vector<GLuint>{fr},
		vector<string>{"velocity_texture"}
	);
	auto ar = advection.execute();


	float dx = 1;
	float dt = 1;
	float nu = 0.005;
	float alpha = dx * dx / (nu * dt);
	float rBeta = 1. / (4 + dx * dx / (nu * dt));

	static Process * diffusion = &diffusiona;	// assign once, use later

	GLuint drr = ar;	// diffusion read result
	GLuint dwr;			// diffusion write result
	for (int n = 0; n < 10; n++)
	{
		diffusion->setFloat(alpha, "alpha");
		diffusion->setFloat(rBeta, "rBeta");
		diffusion->storeInputs(
			{drr,drr},
			vector<string>{"x_texture","b_texture"}
		);

		dwr = diffusion->execute();

		// switch
		drr = dwr;
		dwr = 0;
		diffusion = (diffusion == &diffusiona) ? &diffusionb : &diffusiona;
	}
	GLuint dr = drr;		// final result of diffusion iteration









	// pressure calculation
	divergence.storeInputs(
		{dr},
		vector<string>{"w_texture"}
	);
	auto divr = divergence.execute();	// = pressure


	static bool pressure_initialized = false;
	static GLuint pressure_texture;
	if (!pressure_initialized)
	{
		pressure_initialized = true;
		auto pir = pressure_initial.execute();
		pressure_texture = pir;
	}
	


	alpha = -dx*dx;
	rBeta = 1. / 4.;

	static Process * pressure = &pressurea;
	// set pressure to zero as initial guess

	//glBindTexture(GL_TEXTURE_2D, pressure_texture);
	//const float pzero[3 * 100 * 100] = {};
	//glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB32F, g_sim_w, g_sim_h, 0, GL_RGB, GL_FLOAT, pzero);

	// * actually, keep last pressure for now

	GLuint prr = pressure_texture;	// pressure read result
	GLuint pwr;			// pressure write result
	for (int n = 0; n < 10; n++)
	{
		pressure->setFloat(alpha, "alpha");
		pressure->setFloat(rBeta, "rBeta");
		pressure->storeInputs(
			{prr, divr},
			vector<string>{"x_texture", "b_texture"}
		);

		pwr = pressure->execute();

		// switch
		prr = pwr;
		pwr = 0;
		pressure = (pressure == &pressurea) ? &pressureb : &pressurea;
	}
	GLuint pr = prr;		// final result of pressure iteration
	pressure_texture = pr;


	gradient_subtraction.storeInputs(
		{ pressure_texture,dr},
		vector<string>{"p_texture","w_texture"}
	);
	auto gsr = gradient_subtraction.execute();

	// success :) October 28, 2016 11:41 pm


	velocity_visualize.storeInputs(
		{pressure_texture,
		//ar
		//dr		// diffusion
		//fr
		gsr 
	},
		vector<string>{"pressure_texture","velocity_texture"}
	);
	auto vvr = velocity_visualize.execute();

	

	tts.storeTTSInput(vvr);
	tts.execute();


	// visualize

	static bool pp_initialized = false;
	static GLuint pp_texture;
	if (!pp_initialized)
	{
		pp_initialized = true;
		auto ppinitr = point_position_initialize.execute();
		pp_texture = ppinitr;
	}
	


	static Process * point_position_integrator = &point_position_integratora;
	GLuint pprr = pp_texture;	// ppi read result
	GLuint ppwr;			// ppi write result
	{
		point_position_integrator->storeInputs(
			{ gsr, pprr},
			vector<string>{"velocity_texture", "point_position_texture"}
		);

		ppwr = point_position_integrator->execute();

		// switch
		pprr = ppwr;
		ppwr = 0;
		point_position_integrator = (point_position_integrator == &point_position_integratora) ? &point_position_integratorb : &point_position_integratora;
	}
	GLuint ppr = pprr;		// final result of point position integration
	pp_texture = ppr;
	


	vertex_visualizer.storeInputs(
		{ppr},
		vector<string>{"point_position_texture"}
	);

	

	vertex_visualizer.execute();

	velocity_texture = gsr;
	
}