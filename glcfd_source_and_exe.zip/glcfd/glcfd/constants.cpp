#include "constants.h"



int g_sim_w = 100;
int g_sim_h = 100;
int g_screen_w = 800;
int g_screen_h = 800;

int g_screen_x = 100;
int g_screen_y = 100;