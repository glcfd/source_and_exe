#include "VertexVisualizer.h"
#include <assert.h>
#include "shaders.h"
#include "constants.h"

void VertexVisualizer::setInputs()
{
	assert(constructed);

	glUseProgram(program);


	int n = input_texs.size();
	for (int i = 0; i < n; i++)
	{
		auto tex = input_texs[i];
		auto uname = input_uniform_names[i];
		auto u = glGetUniformLocation(program, uname.c_str());


		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, tex);


		glUniform1i(u, i);
	}

}
void VertexVisualizer::storeInputs(vector<GLuint> texs, vector<string> & uniform_names)
{
	assert(constructed);
	input_texs = texs;
	input_uniform_names = uniform_names;
}
void VertexVisualizer::setInt(int i, string name)
{
	auto u = glGetUniformLocation(program, name.c_str());
	glUseProgram(program);
	glUniform1i(u, i);
}
void VertexVisualizer::setFloat(float f, string name)
{
	auto u = glGetUniformLocation(program, name.c_str());
	glUseProgram(program);
	glUniform1f(u, f);
}
void VertexVisualizer::execute()
{
	//glPointSize(5.f);
	//glPointSize(3);
	//glEnable(GL_POINT_SMOOTH);
	glBindFramebuffer(GL_FRAMEBUFFER, 0);
	glViewport(0, 0, g_screen_w, g_screen_h);
	//glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//precondition: framebuffer is bound, viewport is set, 
	// glClear is called, other things are drawn



	assert(constructed);

	glUseProgram(program);
	setInputs();

	//1st attribute buffer : vertices
	//glEnableVertexAttribArray(0);
	//glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer);
	//glVertexAttribPointer(
	//	0,			// attribute 0.
	//	3,			// size
	//	GL_FLOAT,	// type
	//	GL_FALSE,	// normalized
	//	0,			// stride
	//	(void*)0	// array buffer offset
	//);

	glDrawArrays(GL_POINTS, 0, num_verts);
	//glDisableVertexAttribArray(0);
}

VertexVisualizer::VertexVisualizer() : constructed(false)
{

}
VertexVisualizer::VertexVisualizer(int num_verts_, string vs_file, string fs_file)
	: constructed(true), num_verts(num_verts_)
{


	program = LoadShaders(vs_file.c_str(), fs_file.c_str());
	
	glGenVertexArrays(1, &vertexarray);
	glBindVertexArray(vertexarray);

	//glGenBuffers(1, &vertexbuffer);
	//glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer);

	//num_verts = 6;
	//const float s = .5f;
	//GLfloat vs[] = {
	//	-s, -s, 0.0f,
	//	s, -s, 0.0f,
	//	-s,  s, 0.0f,
	//	-s,  s, 0.0f,
	//	s, -s, 0.0f,
	//	s,  s, 0.0f,
	//};
	
	//glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * 3 * num_verts, NULL, GL_STATIC_DRAW);
	//glBufferData(GL_ARRAY_BUFFER, sizeof(vs), vs, GL_STATIC_DRAW);

}

VertexVisualizer::~VertexVisualizer()
{
}
