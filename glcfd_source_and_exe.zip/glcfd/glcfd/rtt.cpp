#include "rtt.h"
#include "shaders.h"
#include "constants.h"

static GLuint FramebufferName = 0;	// The framebuffer, which regroups 0, 1, or more textures, 
									// and 0 or 1 depth buffer.

static GLuint renderedTexture;

static GLuint quad_VertexArrayID;

static GLuint quad_vertexbuffer;

static GLuint quad_programID;
static GLuint texID;


static GLuint rtt_programID;
static GLuint rtt_timeID;

static GLuint tts_programID;
static GLuint tts_renderedTextureID;

static const GLfloat g_quad_vertex_buffer_data[] = {
	-1.0f, -1.0f, 0.0f,
	1.0f, -1.0f, 0.0f,
	-1.0f,  1.0f, 0.0f,
	-1.0f,  1.0f, 0.0f,
	1.0f, -1.0f, 0.0f,
	1.0f,  1.0f, 0.0f,
};

static void rttSafeInitialize()
{
	static bool initialized = false;
	if (initialized) return;
	initialized = true;


	glGenFramebuffers(1, &FramebufferName);
	glBindFramebuffer(GL_FRAMEBUFFER, FramebufferName);

	glGenTextures(1, &renderedTexture);

	// "Bind" the newly created texture : all future texture functions will modify this texture
	glBindTexture(GL_TEXTURE_2D, renderedTexture);

	// Give an empty image to OpenGL (the last "0")
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, g_sim_w, g_sim_h, 0, GL_RGB, GL_UNSIGNED_BYTE, 0);

	// Poor filtering. Needed !
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	//// The depth buffer (this is optional)
	//GLuint depthrenderbuffer;
	//glGenRenderbuffers(1, &depthrenderbuffer);
	//glBindRenderbuffer(GL_RENDERBUFFER, depthrenderbuffer);
	//glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT, 1024, 768);
	//glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, depthrenderbuffer);

	// Set "renderedTexture" as our color attachment #0
	glFramebufferTexture(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, renderedTexture, 0);

	// Set the list of draw buffers.
	GLenum DrawBuffers[1] = { GL_COLOR_ATTACHMENT0 };
	glDrawBuffers(1, DrawBuffers);	// "1" is the size of DrawBuffers

	// Always check that our framebuffer is ok
	if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
		assert(false);
	
	



	glGenVertexArrays(1, &quad_VertexArrayID);
	glBindVertexArray(quad_VertexArrayID);

	glGenBuffers(1, &quad_vertexbuffer);
	glBindBuffer(GL_ARRAY_BUFFER, quad_vertexbuffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(g_quad_vertex_buffer_data), g_quad_vertex_buffer_data, GL_STATIC_DRAW);

	// Create and compile our GLSL program from the shaders
	//quad_programID = LoadShaders("Passthrough_vs.glsl", "rtt_fs.glsl");
	rtt_programID = LoadShaders("passthrough_vs.glsl", "rtt_fs.glsl");
	//texID = glGetUniformLocation(quad_programID, "renderedTexture");
	rtt_timeID = glGetUniformLocation(rtt_programID, "time");

	tts_programID = LoadShaders("passthrough_vs.glsl", "tts_fs.glsl");
	tts_renderedTextureID = glGetUniformLocation(tts_programID, "renderedTexture");
}



void rtt()
{
	rttSafeInitialize();


	// render to our framebuffer
	glBindFramebuffer(GL_FRAMEBUFFER, FramebufferName);
	glViewport(0, 0, g_sim_w, g_sim_h);


	// Clear the screen
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Use our shader
	glUseProgram(rtt_programID);

	// set uniforms
	glUniform1f(rtt_timeID, (float)(glfwGetTime()*10.0f));

	// 1st attribute buffer : vertices
	glEnableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, quad_vertexbuffer);
	glVertexAttribPointer(
		0,	// attribute 0. No particulare reason for 0, but must match the layout in the vs
		3,	// size
		GL_FLOAT,	// type
		GL_FALSE,	// normalized?
		0,			// stride
		(void*)0	// array buffer offset
	);

	// Draw the triangles!
	glDrawArrays(GL_TRIANGLES, 0, 6);

	glDisableVertexAttribArray(0);




	// render to screen
	glBindFramebuffer(GL_FRAMEBUFFER, 0);

	// render on the whole framebuffer, complete from the lower left corner to the upper right
	glViewport(0, 0, g_screen_w, g_screen_h);

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glUseProgram(tts_programID);

	// Bind texture in Texture Unit 0
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, renderedTexture);

	// Set our "renderedTexture" sampler to user Texture Unit 0
	glUniform1i(tts_renderedTextureID, 0);

	// 1st attribute buffer : vertices
	glEnableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, quad_vertexbuffer);
	glVertexAttribPointer(
		0,			// attribute 0.
		3,			// size
		GL_FLOAT,	// type
		GL_FALSE,	// normalized
		0,			// stride
		(void*)0	// array buffer offset
	);

	glDrawArrays(GL_TRIANGLES, 0, 6);
	glDisableVertexAttribArray(0);

}