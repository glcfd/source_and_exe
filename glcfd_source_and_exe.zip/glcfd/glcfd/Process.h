#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include "constants.h"
#include <vector>
#include <string>
using namespace std;
class Process
{

public:

	enum ResultType {
		NA,
		FLOAT32C1,
		FLOAT32C2,
		FLOAT32C3,
	};

private:
	bool constructed = false;
	bool renderToScreen;
	int w;
	int h;
	
	GLuint framebuffer;
	GLuint renderedtexture;
	GLuint quad_vertexarray;
	GLuint quad_vertexbuffer;
	GLuint program;

	ResultType result_type;
	GLint internalformat;
	GLint format;
	GLint type;

	void setInputs();

	vector<GLuint> input_texs;
	vector<string> input_uniform_names;

	void setType(ResultType rt);

public:
	static string TTS_FS_FILE;
	GLuint getResult();
	
	GLuint execute(bool clear = true);

	void storeInputs(vector<GLuint> texs, vector<string> & uniform_names);

	void storeTTSInput(GLuint tex);

	void setInt(int i, string name);
	void setFloat(float f, string name);

	Process();

	Process(
		string fs_file
		);
	~Process();
};

