#include <stdio.h>
#include <stdlib.h>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>

#include "draw.h"
#include "rtt.h"
#include "constants.h"
#include "rtt2.h"
using namespace glm;

static bool allowExecuteOnce = true;

static bool mouseIsDown = false;

static double lastx, lasty;

void mouse_button_callback(GLFWwindow * window, int button, int action, int mods)
{
	if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS)
	{
		mouseIsDown = true;
		allowExecuteOnce = true;

		double xpos, ypos;
		glfwGetCursorPos(window, &xpos, &ypos);
		lastx = xpos;
		lasty = ypos;
	}
	else if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_RELEASE) {
		mouseIsDown = false;
	}
}

static void cursor_position_callback(GLFWwindow* window, double xpos, double ypos)
{
	if (mouseIsDown)
	{
		double x = xpos;
		double y = ypos;

		int i = x / (float)g_screen_w * g_sim_w;
		int j = g_sim_h - y / (float)g_screen_h * g_sim_h;

		float q = (float)g_screen_w / g_sim_w;

		float s = .5;
		float vx =  (x - lastx);
		float vy =  -(y - lasty) ;
		vx *= 1 / q;
		vy *= 1 / q;
		vx *= s;
		vy *= s;
		

		rtt2_addForce(i, j, vx, vy);

		lastx = x;
		lasty = y;
	}
}


void main()
{
	if (!glfwInit())
	{
		fprintf(stderr, "Failed to initialize GLFW\n");
		return;
	}

	glfwWindowHint(GLFW_SAMPLES, 4);	// 4x antialiasing
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);		// We want OpenGL 3.3
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);		
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);	// To make MacOS happy; should not be needed
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);	// We don't want the old OpenGL

	// Open a window and create its OpenGL context
	GLFWwindow * window;	// (In the accompanying source code, this vareiable is global)
	window = glfwCreateWindow(g_screen_w, g_screen_h, "Tutorial 01", NULL, NULL);
	glfwSetWindowPos(window, g_screen_x, g_screen_y);
	if (window == NULL) {
		fprintf(stderr, "Failed to open GLFW window. If you have an Intel GPU, they are not 3.3 compatible. Try the 2.1 version of the tutorials.\n");
		glfwTerminate();
		return;
	}

	glfwMakeContextCurrent(window);	// Initialize GLEW
	glewExperimental = true;	// Needed in core profile
	if (glewInit() != GLEW_OK) {
		fprintf(stderr, "Failed to initialize GEW\n");
		return;
	}

	glfwSetInputMode(window, GLFW_STICKY_KEYS, GL_TRUE);

	glfwSetMouseButtonCallback(window, mouse_button_callback);
	glfwSetCursorPosCallback(window, cursor_position_callback);

	do {

		if (allowExecuteOnce)
		{
			allowExecuteOnce = false;
			rtt2();
			allowExecuteOnce = true;
		}
		

		//draw();
		//rtt();
		

		// Draw nothing, see you in tutorial 2!
		// Swap buffers
		glfwSwapBuffers(window);
		glfwPollEvents();



	} // Check if the ESC key was pressed or the window was closed
	while (glfwGetKey(window, GLFW_KEY_ESCAPE) != GLFW_PRESS && glfwWindowShouldClose(window) == 0);
}